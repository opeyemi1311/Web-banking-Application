<?php
include('../../session.php');

$sql = "SELECT SUM(invest_bonus) as total_investbonus FROM `investment` WHERE email ='$user_check';";
$result = mysqli_query($connection, $sql);
$total_investbonus = 0;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $total_investbonus = $row["total_investbonus"];
        break;
    }
} 

$_SESSION["total_investbonus"] = $total_investbonus;
?>