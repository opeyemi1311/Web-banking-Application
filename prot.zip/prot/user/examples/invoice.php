<?php
include('../../session.php');

?>
           
<!DOCTYPE html>

<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice</title>

    <link href="invoke/invoice_files/all.min.css" rel="stylesheet">
    <link href="invoke/invoice_files/invoice.css" rel="stylesheet">

</head>
<body>

    

    <div class="container-fluid invoice-container">

        
            <div class="row">
                <div class="col-sm-7">

                                            <p><img src="invoke/invoice_files/investineverydaypay.jpg" title="cradle2fame"></p>
                                        <h3>Invoice #<?php
    echo $second_final; 
    ?></h3>

                </div>
                <div class="col-sm-5 text-center">

                    <div class="invoice-status">
                                                    <span class="unpaid">Unpaid</span>
                                            </div>

                                            
                        <div class="payment-btn-container" align="center">
                            <p>Once you've paid, email us at <strong>sales@investineverydaypay.com</strong> or call <strong>07066016167</strong> to credit your account.</p>
                        </div>
                    
                </div>
            </div>

            <hr>

            
            <div class="row">
                <div class="col-sm-6">
                    <strong>Payment Method:</strong><br>
                    <span class="small-text">
                                                    <form method="post" action="" class="form-inline">
                                
                                <input class="form-control select-inline" type="text" value="Bank Payment Details" name="bank_details" readonly>
                            </form>
                                            </span>
                    <br><br>
                </div>
                <div class="col-sm-6 text-right-sm">
                    <strong>Invoice Date:</strong><br>
                    <span class="small-text">
                        <?php
    echo date("d/m/Y"); 
    ?><br><br>
                    </span>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 pull-sm-right text-right-sm">
                    <strong>Pay To:</strong>
                    <address class="small-text">
                        Account Name: SMO FOOD AND FRUIT NIGERIA LIMITED<br>
Account No: 6194762015<br>
Bank: FCMB

                    </address>
                </div>
                <div class="col-sm-6">
                    <strong>Invoiced To:</strong>
                    <address class="small-text">
                                                <?php
    echo $first_final; 
    ?>, <br>
                      Phone Number  <strong> <?php
    echo $second_final; 
    ?> </strong><br>
                   Contact address:     <?php echo $third_final;  ?>
                                            </address>
                </div>
            </div>


            <br>

            
            
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Invoice Items</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong>Description</strong></td>
                                    <td width="20%" class="text-center"><strong>Amount</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                                                    <tr>
                                        <td>Invest in EverydayPay 
    </td>
                                        <td class="text-center">&#8358;<?php
    echo $_SESSION["investment"]; 
    ?>.00</td>
                                    </tr>
                                                                    
                                                                <tr>
                                    <td class="total-row text-right"><strong>Sub Total</strong></td>
                                    <td class="total-row text-center">&#8358;<?php
     
    ?>.00</td>
                                </tr>
                                                                   
                                <tr>
                                    <td class="total-row text-right"><strong>Total</strong></td>
                                    <td class="total-row text-center">&#8358;<?php
    echo $_SESSION["investment"]; 
    ?>.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            
            

            <div class="pull-right btn-group btn-group-sm hidden-print">
                <a href="javascript:window.print()" class="btn btn-default"><i class=""></i> Print</a>

            </div>

        
    </div>
    
    


    <p class="text-center hidden-print"><a href="dashboard.php">« Back to Dashboard</a></p>


</body></html>
            