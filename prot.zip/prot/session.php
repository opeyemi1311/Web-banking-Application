<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysqli_connect("localhost", "root", "");
// Selecting Database
$db = mysqli_select_db($connection, "smo");

session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];



// SQL Query To Fetch Complete Information Of User
 $first=mysqli_query($connection, "select name from user_table where email='$user_check'");
$first_fetch = mysqli_fetch_assoc($first);
$first_final =$first_fetch['name'];


// i will like to get the code in here, this session is created and accessible to all pages



// SQL Query To Fetch Complete Information Of User
$second=mysqli_query($connection, "select phone_number from user_table where email='$user_check'");
$second_fetch = mysqli_fetch_assoc($second);
$second_final =$second_fetch['phone_number'];



$third=mysqli_query($connection, "select address from user_table where email='$user_check'");
$third_fetch = mysqli_fetch_assoc($third);
$third_final =$third_fetch['address'];

// fetch out bonus amount  
$sql = "SELECT SUM(bonus) as total_bonus FROM login_bonus WHERE email ='$user_check';";
$result = mysqli_query($connection, $sql);
$total_bonus = 0;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $total_bonus = $row["total_bonus"];
        break;
    }
} 

$_SESSION["total_bonus"] = $total_bonus;

// total investment

$sql = "SELECT SUM(amount) as total_investment FROM `investment` WHERE email ='$user_check';";
$result = mysqli_query($connection, $sql);
$total_investment = 0;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $total_investment = $row["total_investment"];
        break;
    }
} 

$_SESSION["total_investment"] = $total_investment;



// total investment bonus

$sql = "SELECT SUM(invest_bonus) as total_investbonus FROM `investment` WHERE email ='$user_check';";
$result = mysqli_query($connection, $sql);
$total_investbonus = 0;

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        $total_investbonus = $row["total_investbonus"];
        break;
    }
} 

$_SESSION["total_investbonus"] = $total_investbonus;


//total bonus



/*
$last=mysqli_query($connection, "select sum bonus from login_bonus where email='$user_check'");
$last_fetch = mysqli_fetch_assoc($last);
$last_final =$last_fetch['bonus'];


$country=mysqli_query($connection, "select country_of_residence from users_profile where email='$user_check'");
$country_fetch = mysqli_fetch_assoc($country);
$country_final =$country_fetch['country_of_residence']; */


$ses_sql=mysqli_query($connection, "select email from user_table where email='$user_check'");
$row = mysqli_fetch_assoc($ses_sql);
$login_session =$row['email'];
if(!isset($login_session)){
mysqli_close($connection); // Closing Connection
header('Location: login.php'); // Redirecting To Home Page
}
?>