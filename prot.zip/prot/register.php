<?php


$conn= mysqli_connect('localhost', 'root', '','smo');

 
 //
 //echo "connected successfully";
 //die();
 $password= $_POST['password'];
 $pass_res= $_POST['re_pass'];
 if($password != $pass_res) {
   echo "Plesea go back";
   //header("location: signup.php");
   exit(0);
 }
 

 $email = $_POST['email'];
 $query = mysqli_query($conn, "select * from user_table where email='$email'");
$rows = mysqli_num_rows($query);
if ($rows == 1) {
echo 'Email already exists. Try using another email or Log in. Please go back and act accordingly';
exit(0);
} 

$name = $_POST['name'];
$password= $_POST['password'];
$password=md5($password);
 

 

$adds['name']=$conn->real_escape_string($_POST['name']);

$adds['email']=$conn->real_escape_string($_POST['email']);
$adds['phone_number']=$conn->real_escape_string($_POST['phone_number']);

$adds['address']=$conn->real_escape_string($_POST['address']);
$adds['password']=$conn->real_escape_string($password);
$adds['nationality']=$conn->real_escape_string($_POST['nationality']);
$adds['agree_term']=$conn->real_escape_string($_POST['agree_term']);




$sql="insert into user_table values('".$adds['email']."','".$adds['name']."','".$adds['password']."','".$adds['phone_number']."','".$adds['address']."','".$adds['nationality']."','".$adds['agree_term']."')";










 if ($conn->query($sql)==TRUE){
	 
 //echo "You have registered on InvestDayPaySuccessfully";

   header("Location: ../registration-successful.php");

 }

 else{
 echo 'Error: '. $conn->error;
 }


 
 
 


// close connection


 $conn->close();

 ?>