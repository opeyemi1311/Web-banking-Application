<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['email']) || empty($_POST['password'])) {
$error = "Email or Password is invalid";
}
else
{
// Define $email and $password
$email=$_POST['email'];
$password=$_POST['password'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysqli_connect("localhost", "root", "");
// To protect MySQL injection for Security purpose
$email = stripslashes($email);
$password = stripslashes($password);
$email = mysqli_real_escape_string($connection, $email);
$password = mysqli_real_escape_string($connection, md5($password));
// Selecting Database
$db = mysqli_select_db($connection, "smo");
// SQL query to fetch information of registerd users and finds user match.
$query = mysqli_query($connection, "select * from user_table where password='$password' AND email='$email'");

$rows = mysqli_num_rows($query);
if ($rows == 1) {
$_SESSION['login_user']=$email; // Initializing Session

//the following structure gives user bonus on every
$emailuser = $_SESSION['login_user'];

$date=date("Y-m-d");
$bonus="0.1";

// test if a row is fetched from the data base
$sql = "SELECT *  FROM login_bonus WHERE email = '$emailuser' AND date = '$date'";
$result = $connection->query($sql);
$stu= $result->num_rows;

if ($stu < 10) {
    // insert into login_bons
    $sql = "INSERT INTO login_bonus (email, bonus, date_bonus)
    VALUES ('$emailuser', '$bonus', '$date')";
    
    if ($connection->query($sql) === TRUE) {
        header("location: user/examples/dashboard.php");
    } 
   //insert into login_bonus
} else {
    echo "u can not insert more";
    
}
die();
// test a row is fetched on database







header("location: user/examples/dashboard.php"); // Redirecting To Other Page
} else {
$error = "Email or Password is invalid";
}
mysqli_close($connection); // Closing Connection
}
}
?>