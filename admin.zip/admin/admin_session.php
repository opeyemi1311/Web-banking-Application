<?php
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection = mysqli_connect("localhost", "root", "");
// Selecting Database
$db = mysqli_select_db($connection, "smo");

session_start();// Starting Session
// Storing Session
$user_check_admin=$_SESSION['login_user_admin'];



// SQL Query To Fetch Complete Information Of User
 $first_admin=mysqli_query($connection, "select name from admin_table where email='$user_check_admin'");
$first_fetch_admin = mysqli_fetch_assoc($first_admin);
$first_final_admin =$first_fetch_admin['name'];


// i will like to get the code in here, this session is created and accessible to all pages

$_SESSION ['error_funding']="";










/*
$last=mysqli_query($connection, "select sum bonus from login_bonus where email='$user_check'");
$last_fetch = mysqli_fetch_assoc($last);
$last_final =$last_fetch['bonus'];


$country=mysqli_query($connection, "select country_of_residence from users_profile where email='$user_check'");
$country_fetch = mysqli_fetch_assoc($country);
$country_final =$country_fetch['country_of_residence']; */


$ses_sql=mysqli_query($connection, "select email from admin_table where email='$user_check_admin'");
$row = mysqli_fetch_assoc($ses_sql);
$login_admin_session =$row['email'];
if(!isset($login_admin_session)){
mysqli_close($connection); // Closing Connection
header('Location: login_admin.php'); // Redirecting To Home Page
}
?>