<?php

// Create connection
$conn = mysqli_connect("localhost", "root", "", "smo");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "connected";
die();

$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

 ?>