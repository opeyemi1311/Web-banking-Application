<!DOCTYPE html>

<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice</title>

    <link href="./invoice_files/all.min.css" rel="stylesheet">
    <link href="./invoice_files/invoice.css" rel="stylesheet">

</head>
<body>

    

    <div class="container-fluid invoice-container">

        
            <div class="row">
                <div class="col-sm-7">

                                            <p><img src="invoice_files/kings_small.png" title="Kingsprimetv"></p>
                                        <h3>Invoice #256879</h3>

                </div>
                <div class="col-sm-5 text-center">

                    <div class="invoice-status">
                                                    <span class="unpaid">Unpaid</span>
                                            </div>

                                            <div class="small-text">
                            Due Date: 02/10/2017
                        </div>
                        <div class="payment-btn-container" align="center">
                            <p>Once your payment is made, send a mail to sales@kingsprimetv.com and we will activate your order once payment is confirmed<br>Reference Number: 256879</p>
                        </div>
                    
                </div>
            </div>

            <hr>

            
            <div class="row">
                <div class="col-sm-6">
                    <strong>Payment Method:</strong><br>
                    <span class="small-text">
                                                    <form method="post" action="" class="form-inline">
                                
                                <input class="form-control select-inline" type="text" value="Bank Payment Details" name="bank_details" readonly>
                            </form>
                                            </span>
                    <br><br>
                </div>
                <div class="col-sm-6 text-right-sm">
                    <strong>Invoice Date:</strong><br>
                    <span class="small-text">
                        29/09/2017<br><br>
                    </span>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-6 pull-sm-right text-right-sm">
                    <strong>Pay To:</strong>
                    <address class="small-text">
                        Account Name: Dr. Kingsley Nwachukwu<br>
Account No: 0053236989<br>
Bank: Guaranty Trust Bank PLC

                    </address>
                </div>
                <div class="col-sm-6">
                    <strong>Invoiced To:</strong>
                    <address class="small-text">
                                                Dave Adams<br>
                        vfvfvfvfvfvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv, <br>
                        vfvfvfvfv, vfvfvfvfvf, 110001<br>
                        Nigeria
                                            </address>
                </div>
            </div>


            <br>

            
            
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Invoice Items</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong>Description</strong></td>
                                    <td width="20%" class="text-center"><strong>Amount</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                                                    <tr>
                                        <td>Pro (6GB) Linux Shared Hosting - vfvfvfvf.com.ng (29/09/2017 - 28/09/2018) *</td>
                                        <td class="text-center">N8,500.00</td>
                                    </tr>
                                                                    
                                                                <tr>
                                    <td class="total-row text-right"><strong>Sub Total</strong></td>
                                    <td class="total-row text-center">N8,095.24</td>
                                </tr>
                                                                   
                                <tr>
                                    <td class="total-row text-right"><strong>Total</strong></td>
                                    <td class="total-row text-center">N8,500.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            
            

            <div class="pull-right btn-group btn-group-sm hidden-print">
                <a href="javascript:window.print()" class="btn btn-default"><i class=""></i> Print</a>

            </div>

        
    </div>

    <p class="text-center hidden-print"><a href="https://www.kingsprimetv.com">« Back to Home Page</a></p>


</body></html>