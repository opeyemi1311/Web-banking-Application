<?php
include('../../admin_session.php');
// Create connection
$conn = mysqli_connect("localhost", "root", "", "smo");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id="";
$email= $_POST['email'];
$amount = $_POST['amount'];

$invest_bonus= "";
$invest_date= date("Y-m-d");
$_SESSION['codemail']= $_POST['email'];


// This function will return a random string of specified length 
function random_strings($length_of_string) { 
      
    // md5 the timestamps and returns substring of specified length 
    return substr(md5(time()), 0, $length_of_string); 
} 
  
// This function will generate  Random string of length 10 
//echo random_strings(2); 
//echo "\n"; 
// This function will generate  
// Random string of length 8 
$referal_code= random_strings(4);
$referral_date= date("Y-m-d"); 



$sql = "INSERT INTO investment (email, amount, invest_bonus, invest_date)
VALUES ('$email', '$amount', '$invest_bonus', '$invest_date')";


if (mysqli_query($conn, $sql)) {
   // if(mysqli_query($conn, $sql2)){
    header("location: fund_added.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

 ?>