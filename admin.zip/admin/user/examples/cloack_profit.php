<?php
include('../../admin_session.php');
// Create connection
$conn = mysqli_connect("localhost", "root", "", "smo");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$date= date("Y-m-d");

$query = mysqli_query($conn, "select * from `investment` where profit_date='$date'");
$rows = mysqli_num_rows($query);
if ($rows >= 1) {
header("location: updated_before.php");
exit(0);
} 

$date= date("Y-m-d");
$sql = "UPDATE `investment` SET invest_bonus= (amount*0.05)+ invest_bonus, profit_date='$date'";

if (mysqli_query($conn, $sql)) {
    header("location: profit_added.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

 ?>